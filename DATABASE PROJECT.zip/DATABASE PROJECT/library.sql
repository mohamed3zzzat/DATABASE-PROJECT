CREATE TABLE Librarians (
    LibrarianID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Phone VARCHAR(15),
    Email VARCHAR(100),
    HireDate DATE,
    Shift VARCHAR(50)
);

CREATE TABLE Members (
    MemberID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Phone VARCHAR(15),
    Email VARCHAR(100),
    MembershipDate DATE,
    MembershipStatus VARCHAR(50)
);

CREATE TABLE Categories (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(50),
    Description TEXT
);


CREATE TABLE Books (
    BookID INT PRIMARY KEY,
    Title VARCHAR(100),
    Author VARCHAR(100),
    Genre VARCHAR(50),
    Publisher VARCHAR(100),
    Language VARCHAR(50),
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);

CREATE TABLE Borrowings (
    BorrowID INT PRIMARY KEY,
    MemberID INT,
    BookID INT,
    LibrarianID INT,
    BorrowDate DATE,
    DueDate DATE,
    ReturnDate DATE,
    FOREIGN KEY (MemberID) REFERENCES Members(MemberID),
    FOREIGN KEY (BookID) REFERENCES Books(BookID),
    FOREIGN KEY (LibrarianID) REFERENCES Librarians(LibrarianID)
);

INSERT INTO Librarians VALUES
(1, 'Ahmed', 'Hussein', '01012345678', 'ahmed.hussein@example.com', '2020-07-26', 'Morning'),
(2, 'Mona', 'Ali', '01023456789', 'mona.ali@example.com', '2020-05-23', 'Evening'),
(3, 'Khaled', 'Abdallah', '01134567890', 'khaled.abdallah@example.com', '2020-09-03', 'Night'),
(4, 'Sara', 'Mahmoud', '01245678901', 'sara.mahmoud@example.com', '2021-01-03', 'Evening'),
(5, 'Yasser', 'Saeed', '01056789012', 'yasser.saeed@example.com', '2022-05-12', 'Night'),
(6, 'Eman', 'Fouad', '01167890123', 'eman.fouad@example.com', '2021-07-20', 'Morning'),
(7, 'Alaa', 'Abdelrahim', '01278901234', 'alaa.abdelrahim@example.com', '2022-12-28', 'Evening'),
(8, 'Hoda', 'Mostafa', '01089012345', 'hoda.mostafa@example.com', '2025-02-02', 'Evening'),
(9, 'Mohamed', 'Gamal', '01190123456', 'mohamed.gamal@example.com', '2020-11-08', 'Night'),
(10, 'Dina', 'Abdelaziz', '01201234567', 'dina.abdelaziz@example.com', '2021-05-15', 'Night');

INSERT INTO Members VALUES
(1, 'Ali', 'Omar', '01011111111', 'ali.omar@example.com', '2025-05-03', 'Inactive'),
(2, 'Noha', 'Ashraf', '01022222222', 'noha.ashraf@example.com', '2023-12-01', 'Inactive'),
(3, 'Majed', 'Tarek', '01133333333', 'majed.tarek@example.com', '2025-02-03', 'Active'),
(4, 'Mai', 'Fathy', '01244444444', 'mai.fathy@example.com', '2025-05-12', 'Inactive'),
(5, 'Abdelrahman', 'Hamdy', '01055555555', 'abdelrahman.hamdy@example.com', '2023-04-28', 'Inactive'),
(6, 'Hala', 'Samy', '01166666666', 'hala.samy@example.com', '2025-04-26', 'Active'),
(7, 'Nour', 'Magdy', '01277777777', 'nour.magdy@example.com', '2023-05-05', 'Inactive'),
(8, 'Tamer', 'Ramadan', '01088888888', 'tamer.ramadan@example.com', '2022-12-28', 'Inactive'),
(9, 'Yomna', 'Fares', '01199999999', 'yomna.fares@example.com', '2023-12-06', 'Inactive'),
(10, 'Rana', 'Galal', '01200000000', 'rana.galal@example.com', '2024-04-19', 'Inactive');

INSERT INTO Categories VALUES
(1, 'Novels', 'Fiction and literary works.'),
(2, 'Science', 'Scientific books in various fields.'),
(3, 'History', 'Books on historical events and figures.'),
(4, 'Literature', 'Arabic and world literature.'),
(5, 'Children', 'Educational and fun books for kids.'),
(6, 'Technology', 'Books about tech and information.'),
(7, 'Religion', 'Religious and cultural books.'),
(8, 'Art', 'Books on drawing, music, and theatre.'),
(9, 'Medicine', 'Medical books in various fields.'),
(10, 'Law', 'Legal references and books.');


INSERT INTO Books VALUES
(1, 'Desert Heart', 'Naguib Mahfouz', 'Novel', 'Dar Al Shorouk', 'English', 1),
(2, 'Introduction to Physics', 'Ahmed Zewail', 'Science', 'Dar Al Elm', 'English', 2),
(3, 'Modern Egyptian History', 'Youssef Ziedan', 'History', 'General Book Authority', 'English', 3),
(4, 'Poems from Memory', 'Farouk Shousha', 'Poetry', 'Lebanese Egyptian House', 'English', 4),
(5, 'Best Stories for Kids', 'Mona ElShazly', 'Children', 'Nahdet Misr', 'English', 5),
(6, 'Programming Basics', 'Amr Abdelrahman', 'Tech', 'Tech House', 'English', 6),
(7, 'Worship Rules', 'El Shaarawy', 'Religion', 'Dar Al Salam', 'English', 7),
(8, 'Drawing for Beginners', 'Hany Ismail', 'Art', 'Art House', 'English', 8),
(9, 'Surgery Principles', 'Khaled Abdel Aal', 'Medical', 'Medical House', 'English', 9),
(10, 'Public International Law', 'Hesham Badawy', 'Law', 'University House', 'English', 10);

INSERT INTO Borrowings VALUES
(1, 3, 9, 2, '2024-10-21', '2024-11-04', '2024-11-06'),
(2, 8, 5, 4, '2024-12-15', '2024-12-29', '2025-01-07'),
(3, 9, 5, 10, '2024-11-14', '2024-11-28', '2024-11-19'),
(4, 5, 5, 3, '2024-09-30', '2024-10-14', '2024-10-19'),
(5, 1, 3, 8, '2024-08-21', '2024-09-04', '2024-09-11'),
(6, 1, 4, 7, '2024-08-09', '2024-08-23', '2024-08-24'),
(7, 9, 5, 3, '2024-11-15', '2024-11-29', '2024-11-15'),
(8, 7, 1, 1, '2024-09-02', '2024-09-16', '2024-09-21'),
(9, 5, 4, 3, '2025-01-05', '2025-01-19', '2025-01-30'),
(10, 8, 10, 3, '2024-09-21', '2024-10-05', '2024-10-13');
